
package circle;

public class runnerQ4 {
    public static void main(String[]args){
        Marks s1 = new Marks();
        Marks s2 = new Marks(30,76,56);
        s1.calSum();
        s2.calSum();
        
    }
    
}

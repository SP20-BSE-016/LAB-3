
package circle;

public class runnerQ1 {
    public static void main(String[]args){
        Circle c1 = new Circle();
        c1.CalCircumfarence();
        
    }
    
}


package circle;

public class Circle {
 double radius;
 double pi;
 public Circle(){
     radius = 2;
     pi = 3.14;
 }
 public Circle(int r,double pye){
     radius = r;
     pi = pye;
 }
 
 public void CalCircumfarence(){
     double circumfarence = 2*pi*radius;
     System.out.println("This is the circumfarnce of the  "+ circumfarence);
 }   
}

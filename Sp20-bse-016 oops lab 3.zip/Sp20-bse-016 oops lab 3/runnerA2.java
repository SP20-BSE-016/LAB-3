
package circle;


public class runnerQ5 {
    public static void main(String []args){
        Time t1 = new Time();
        t1.Display();
        Time t2 = new Time(9,34,56);
        t2.Display();
        
    }
    
}

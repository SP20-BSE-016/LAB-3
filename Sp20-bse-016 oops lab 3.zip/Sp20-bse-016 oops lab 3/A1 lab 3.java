
package circle;

public class Marks {
    int m1,m2,m3;
    public Marks(){
        m1 = 69;
        m2 = 87;
        m3 = 54;
    }
     public Marks(int urdu,int chem,int eng){
        m1 = urdu;
        m2 = chem;
        m3 = eng;
     }
     public void calSum(){
         int sum;
         sum = m1+m2+m3;
         System.out.println("total marks are "  + sum);
     }
}

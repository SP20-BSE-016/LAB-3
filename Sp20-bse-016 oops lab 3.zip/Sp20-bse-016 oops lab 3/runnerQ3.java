
package circle;


public class runnerQ3 {
    public static void main(String[]args){
        Distance d1 = new Distance();
        d1.Display();
         Distance d2 = new Distance(3,9);
        d2.Display();
    }
    
}


package circle;

public class runnerQ2 {
    public static void main (String []args){
        Account a1 = new Account();
        Account a2 = new Account(6000);
        
        a1.Deposit(400);
        a1.Withdraw(2000);
        a2.Deposit(1000);
        a2.Withdraw(1500);
    }
    
}


package circle;

public class Distance {
    int feet;
    int inch;
    public Distance(){
        feet = 3;
        inch =12;
        
    }
    public Distance( int i, int j){
        feet = i;
        inch = j;
    }
    public void Display(){
        System.out.println("feets are "+ feet);
        System.out.println("inches are "+ inch);
    }
    
}

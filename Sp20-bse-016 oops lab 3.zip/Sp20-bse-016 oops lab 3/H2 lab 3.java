
package circle;

public class Account {
    int amount;
    public Account(){
        amount = 5000;
    }
    public Account(int a){
        amount = a;
    }
    public void Deposit(int dept){
        int depst;
        depst = dept;
        int total = amount + depst;
        System.out.println( "Current balance is "+ amount + " and you deposit " + dept + " total balance is "+ total);
    }
    public void Withdraw(int width){
        int with;
        with = width;
        int total = amount - with;
        System.out.println("current  balance is "+ amount + " and you withdraw " + width + " total balance is "+ total);
    }
    
}

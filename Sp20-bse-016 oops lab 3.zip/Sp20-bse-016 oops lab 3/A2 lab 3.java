
package circle;

public class Time {
    int hours;
    int minutes;
    int seconds;
    public Time(){
        hours = 11;
        minutes = 33;
        seconds = 23;
    }
    public Time(int h,int m,int s){
        hours = h;
        minutes = m;
        seconds = s;
       
        }
        
            
        
            
    
    public void Display(){
        System.out.println("Now the time is " +hours +":"+ minutes +":"+ seconds);
    }
    
}
